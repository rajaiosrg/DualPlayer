//
//  PlayerTableViewCell.swift
//  WakaoDemo
//
//  Created by Raja Earla on 25/06/22.
//

import UIKit

class PlayerTableViewCell: UITableViewCell {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var leftView: PlayerView!
    @IBOutlet weak var rightView: PlayerView!
    @IBOutlet weak var challengeView: UIView!
    
    var viewModel: PlayerTableViewCellViewModel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        challengeView.backgroundColor = .black
        leftView.backgroundColor = .black
        rightView.backgroundColor = .black
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCellContentWith(_ cellViewModel: PlayerTableViewCellViewModel) {
        viewModel = cellViewModel
        
        leftView.playerViewType = .left
        rightView.playerViewType = .right
        
        leftView.configurePlayer(with: viewModel.leftUrl)
        leftView.layoutIfNeeded()
        rightView.configurePlayer(with: viewModel.rightUrl)
        rightView.layoutIfNeeded()
        
        leftView.playerReachToEndBlock = {[weak self] ended, type in
            self?.setupPlayersUI(ended, type: type)
        }
        
        rightView.playerReachToEndBlock = {[weak self] ended, type in
            self?.setupPlayersUI(ended, type: type)
        }
    }
    
    private func setupPlayersUI(_ ended: Bool, type: PlayerViewType) {
        
        switch type {
        case .left:
          //  leftView.pause()
            rightView.playFromBeginning()
        case .right:
            leftView.playFromBeginning()
         //   rightView.pause()
        }
    }
    
    func playFirstVideo() {
        leftView.playFromBeginning()
    }
    func stopPlayingForNonVisibleCells() {
        leftView.forceStopPlaying()
        rightView.forceStopPlaying()
    }
}

extension UIColor {
    public class var randomColor: UIColor {
        /// Generate between 0 to 1
        let red: CGFloat = CGFloat(drand48())
        let green: CGFloat = CGFloat(drand48())
        let blue: CGFloat = CGFloat(drand48())
        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
}
