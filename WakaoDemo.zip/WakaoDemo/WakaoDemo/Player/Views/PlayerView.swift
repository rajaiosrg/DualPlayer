//
//  PlayerView.swift
//  WakaoDemo
//
//  Created by Raja Earla on 25/06/22.
//

import UIKit
import AVFoundation

enum PlayerViewType: String {
    case left, right
}
typealias OnPlayerReachToEndBlock = ((_ ended: Bool, _ type: PlayerViewType) -> Void)

//https://developer.apple.com/documentation/avfoundation/media_playback/observing_playback_state
// https://santoshkumarjm.medium.com/how-to-design-a-custom-avplayer-to-play-audio-using-url-in-ios-swift-439f0dbf2ff2
class PlayerView: UIView {
    
    // Key-value observing context
    private var playerItemContext = 0
    private var player:AVPlayer?
    private var playerItem:AVPlayerItem?
    private var playerLayer: AVPlayerLayer!
    var playerReachToEndBlock: OnPlayerReachToEndBlock?
    var isOutOfWindow: Bool = false
    var isPlaying: Bool {return player?.rate != 0}
    let requiredAssetKeys = [
        "playable",
        "hasProtectedContent"
    ]
    var playerViewType: PlayerViewType = .left
    private var timeObserverToken: Any?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        observePlayerStates()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        observePlayerStates()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        print(self.bounds)
        playerLayer.frame = self.bounds // CGRect(x:0, y:0, width:10, height:50)
    }
    
    func configurePlayer(with urlString: String?) {
        if let urlString = urlString {
            let url = URL(string: urlString)
            if playerItem == nil {
                playerItem = AVPlayerItem(url: url!)
                
                
                // Register as an observer of the player item's status property
                playerItem?.addObserver(self,
                                        forKeyPath: #keyPath(AVPlayerItem.status),
                                        options: [.old, .new],
                                        context: &playerItemContext)
                
                player = AVPlayer(playerItem: playerItem)
                
                playerLayer = AVPlayerLayer(player: player!)
                playerLayer.frame = self.bounds // CGRect(x:0, y:0, width:10, height:50)
                self.layer.addSublayer(playerLayer)
                addPeriodicTimeObserver()
            } else {
                // player item already exists and do handle the continue
                print("Playerm item is already added")
            }
        }
    }
    
    func addPeriodicTimeObserver() {
        // Invoke callback every half second
        let interval = CMTime(seconds: 0.5,
                              preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        // Add time observer. Invoke closure on the main queue.
        timeObserverToken =
        player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) {
            [weak self] time in
            // update player transport UI
            print(time)
        }
    }
    
    func play() {
        if !isPlaying {
            isOutOfWindow = false
            player!.play()
        }
    }
    
    func pause() {
        print("paused")
        player!.pause()
    }
    
    func forceStopPlaying() {
        isOutOfWindow = true
        player?.pause()
    }
    
    func playFromBeginning() {
        if let player = player {
            if !isPlaying {
                
                print("player rate -- \(player.rate) <==> type -- \(playerViewType.rawValue)")
                var isItInEndPosition = false
                if let currentItem = player.currentItem {
                    let duration: CMTime = currentItem.duration //total time
                    let currentTime: CMTime = currentItem.currentTime() //playing time
                    isItInEndPosition = duration.value == currentTime.value
                }
                isOutOfWindow = false
                if isItInEndPosition {
                    player.seek(to: .zero, completionHandler: {[weak self] success in
                        player.play()
                    })
                } else {
                    player.play()
                }
                
            } else {
                // handle playing
                print("\(playerViewType.rawValue) playing")
            }
        }
    }
    
    func observePlayerStates() {
        print("observePlayerStates")
        NotificationCenter.default.addObserver(self, selector: #selector(videoDidEnd), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
    }
    
    @objc func videoDidEnd(notification: NSNotification) {        //do something here
        print("\(playerViewType.rawValue) player ended")
        
            if let p = notification.object as? AVPlayerItem, p == player?.currentItem && !isOutOfWindow {
                print("same item")
                if let playerReachToEndBlock = playerReachToEndBlock {
                    playerReachToEndBlock(true, playerViewType)
                }
            }
        
    }
    
    @objc func playButtonTapped(_ sender:UIButton) {
        if player?.rate == 0 {
            player!.play()
        } else {
            player!.pause()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?,
                               of object: Any?,
                               change: [NSKeyValueChangeKey : Any]?,
                               context: UnsafeMutableRawPointer?) {
        
        // Only handle observations for the playerItemContext
        guard context == &playerItemContext else {
            super.observeValue(forKeyPath: keyPath,
                               of: object,
                               change: change,
                               context: context)
            return
        }
        
        if keyPath == #keyPath(AVPlayerItem.status) {
            let status: AVPlayerItem.Status
            if let statusNumber = change?[.newKey] as? NSNumber {
                status = AVPlayerItem.Status(rawValue: statusNumber.intValue)!
            } else {
                status = .unknown
            }
            
            // Switch over status value
            switch status {
            case .readyToPlay:
                // Player item is ready to play.
                print("\(playerViewType.rawValue) readyToPlay")
            case .failed:
                // Player item failed. See error.
                print("failed to play")
            case .unknown:
                // Player item is not yet ready.
                print("unknown")
            @unknown default:
                print("default")
            }
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}

