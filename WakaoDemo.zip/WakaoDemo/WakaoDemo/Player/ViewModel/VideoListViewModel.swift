//
//  VideoListViewModel.swift
//  WakaoDemo
//
//  Created by Raja Earla on 25/06/22.
//

import Foundation
import UIKit

protocol VideoListViewModelProtocol: AnyObject {}

class VideoListViewModel {
    weak var delegate: VideoListViewModelProtocol?
    private var cellViewModels = [PlayerTableViewCellViewModel]()
    
    var rowCount: Int {
        return cellViewModels.count
    }
    
    init(delegate: VideoListViewModelProtocol?) {
        self.delegate = delegate
        prepareDatasource()
    }
    
    func prepareDatasource() {
        /*
         https://media.wakao.app/h264-720/digjjzi7-1656074236.mp4
         https://media.wakao.app/h264-720/rnsxek2x-1656072929.mp4
         
         https://media.wakao.app/h264-720/7cn2v1r1-1656072887.mp4
         https://media.wakao.app/h264-720/96kj9iqm-1656072676.mp4
         
         https://media.wakao.app/h264-720/2fr517ix-1656072628.mp4
         https://media.wakao.app/h264-720/d4zju150-1656072545.mp4
         
         https://media.wakao.app/h264-720/eb0b3mh9-1656072525.mp4
         https://media.wakao.app/h264-720/4cckrqnt-1656072298.mp4
         
         https://media.wakao.app/h264-720/l65yajlq-1656072280.mp4
         https://media.wakao.app/h264-720/mb7n3f1o-1656072190.mp4
         
         https://media.wakao.app/h264-720/k6p5p0ke-1656072131.mp4
         https://media.wakao.app/h264-720/a56o82mp-1656072126.mp4
         
         https://media.wakao.app/h264-720/c9bhbt8x-1656072095.mp4
         https://media.wakao.app/h264-720/youz9tpo-1656072012.mp4
         
         https://media.wakao.app/h264-720/8ijsfvr9-1656071927.mp4
         https://media.wakao.app/h264-720/woq4m9nb-1656071842.mp4
         
         https://media.wakao.app/h264-720/z7eloyzl-1656071790.mp4
         https://media.wakao.app/h264-720/atm64crw-1656071671.mp4
         
         https://media.wakao.app/h264-720/d74131dr-1656071625.mp4
         https://media.wakao.app/h264-720/94j1vljb-1656071251.mp4
         */
        
        guard let path = Bundle.main.path(forResource: "Wakao", ofType: "plist"),
        let dukaanPlistDict = NSDictionary(contentsOfFile: path) else {
            return
        }
        var videos: [VideoInfo]!
        if let videosJson = dukaanPlistDict["videos"] as? String {
            do {
                let videosListModel = try JSONDecoder().decode([VideoInfo].self, from: videosJson.data(using: .utf8)!)
                videos = videosListModel
            } catch {
                print("Error in decoding faqs \(error.localizedDescription)")
            }
        }
        cellViewModels = videos.map {PlayerTableViewCellViewModel($0)}
        print(cellViewModels.count)
    }
    
    func cellViewModelAt(_ indexPath: IndexPath) -> PlayerTableViewCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
}


class PlayerTableViewCellViewModel {
    let cellIdentifier = "PlayerTableViewCell"
    private var video: VideoInfo!
    var leftUrl: String?
    var rightUrl: String?
    init(_ video: VideoInfo) {
        self.video = video
        self.leftUrl = video.ownerUrl
        self.rightUrl = video.challengerUrl
    }
}

struct VideoInfo: Codable {
    var id: Int
    var ownerUrl: String?
    var challengerUrl: String?
    var ownerName: String = ""
    var challengerName: String = ""
}
