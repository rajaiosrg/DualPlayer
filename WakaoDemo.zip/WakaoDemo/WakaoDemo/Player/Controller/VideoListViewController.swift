//
//  VideoListViewController.swift
//  WakaoDemo
//
//  Created by Raja Earla on 25/06/22.
//

import UIKit

class VideoListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    private var viewModel: VideoListViewModel!
    private var previousVisibleCell: PlayerTableViewCell?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel = VideoListViewModel(delegate: self)
        let height = UIScreen.main.bounds.height
        print(height)
        tableView.rowHeight = height
        tableView.estimatedRowHeight = height
        tableView.separatorStyle = .none
        tableView.isPagingEnabled = true
        tableView.bounces = false
        tableView.sectionHeaderHeight = 0
        tableView.sectionFooterHeight = 0
        if #available(iOS 15.0, *) {
            tableView.sectionHeaderTopPadding = 0
        }
        
    }
}

extension VideoListViewController: VideoListViewModelProtocol {
    
}

extension VideoListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.rowCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellViewModel = viewModel.cellViewModelAt(indexPath)
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellViewModel.cellIdentifier, for: indexPath) as? PlayerTableViewCell else {return UITableViewCell()}
        cell.configureCellContentWith(cellViewModel)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UIScreen.main.bounds.height
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate{
          scrollToMostVisibleCell()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        scrollToMostVisibleCell()
    }

    func scrollToMostVisibleCell(){
      let visibleRect = CGRect(origin: tableView.contentOffset, size: tableView.bounds.size)
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        if let visibleIndexPath: IndexPath = tableView.indexPathForRow(at: visiblePoint) {
            print(visibleIndexPath)
            if let visibleCell = tableView.cellForRow(at: visibleIndexPath) as? PlayerTableViewCell, visibleCell != previousVisibleCell {
                previousVisibleCell?.stopPlayingForNonVisibleCells()
                visibleCell.playFirstVideo()
                previousVisibleCell = visibleCell
            }
            tableView.scrollToRow(at: visibleIndexPath, at: .top, animated: true)
        }
    }
}

